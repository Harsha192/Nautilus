package com.fawzan.de;

/*Triangle class to draw a triangle in the JFrame window*/

import java.awt.*;
import java.awt.geom.Line2D;

public class Triangle extends Shape {

    /*x,y cordinates of the 3 points to draaw the triangle*/
    private int x1,y1;
    private int x2,y2;
    private int x3,y3;

    /*Constructor with x,y cordinates of 3 points*/
    public Triangle(int x1,int y1,int x2,int y2,int x3,int y3){
       this.x1 = x1;
       this.y1 = y1;
       this.x2 = x2;
       this.y2 = y2;
       this.x3 = x3;
       this.y3 = y3;
    }

    /*Constructor with x,y cordinates of 3 points and the color*/
    public Triangle(Color color,int x1, int y1, int x2, int y2, int x3, int y3){
        super(color);
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.x3 = x3;
        this.y3 = y3;
   }

    /*Overridden method from Shape class*/
    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(this.color);

        //draw 3 lines to complete the triangle
        g2.draw(new Line2D.Double(x1,y1,x2,y2));
        g2.draw(new Line2D.Double(x2,y2,x3,y3));
        g2.draw(new Line2D.Double(x3,y3,x1,y1));
    }
}
