package com.fawzan.de;

/*Circle class to draw the circle */
import java.awt.*;

public class Circle extends Shape {

    /*x,y cordinates and radius of the circle to draw*/
    private int x,y;
    private int radius;

    /*constructor with x,y cordinates and radius of the circle and the color*/
    public Circle(int x, int y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    /*constructor with x,y cordinates and radius of the circle */
    public Circle(Color color, int x, int y, int radius) {
        super(color);
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    /*Overridden method from Shape class*/
    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(this.color);

        /*Draw the circle using drawOval() method
        * In the circle height and width are same and it's radius
        * */
        g2.drawOval(x,y,radius,radius);
    }
}
