package com.fawzan.de;
/*
* Author        : H.R.H.G. Kosala (E/13/192)
* Last Modified : 2016.08.02
* Problem       : Draw the Nautilus and some Shapes
* */

/*
* This programme is to draw the nautilus currve in a JFrame window.
* Nautilus, Square, Shape and Curve classes are help draw the nautilus using curves
* and squares. Shape class is to add colors to the lines and by extending that draw method
* can be overidden to draw the compenents.
* Line. Triangle, Circle class for draw line, triangle and a circle
* */

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Main extends JPanel {

    /*Declare the width and the height of the JFrame*/
    private static int WIDTH = 600;
    private static int HEIGHT = 400;

    private static ArrayList<Shape> listOfShapes;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Some Shapes");  //creating the JFrame window

        frame.setContentPane(new Main());
        frame.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        frame.setSize(WIDTH, HEIGHT);
        frame.pack();
        frame.setVisible(true);  //set to visible the window
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Line line = new Line(Color.red, 0, 0, 650, 400);
        //line.draw(g);

        Square square = new Square(Color.green, 140, 30, 300, 300);
        //square.draw(g);

        Triangle triangle = new Triangle(Color.DARK_GRAY,300,20,150,300,450,300);
        //triangle.draw(g);

        Circle circle = new Circle(Color.GREEN,180,90,200);
        //circle.draw(g);

        Curve curve = new Curve(200,100,300,300,90,90);
        //curve.draw(g);

        Nautilus nautilus = new Nautilus(80,50);
        nautilus.draw(g);
    }
}
