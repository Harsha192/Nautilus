package com.fawzan.de;

/*This class to draw a square in the JFrame window*/

import java.awt.*;
import java.awt.geom.Line2D;

public class Square extends Shape {
    /*starting x,y cordinates and width and height of the square
    * For nautilus here height = width
    * */
    private int x, y;
    private int width, height;

    /*constructor with the x,y cordinates and height and width*/
    public Square(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    /*constructor with the color x,y cordinates and height and width*/
    public Square(Color color, int x, int y, int width, int height) {
        super(color);
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    /*Overridden method from Shape class*/
    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(this.color);

        //draw the 4 lines of the to complete the square
        g2.draw(new Line2D.Double(x, y, x + width, y));
        g2.draw(new Line2D.Double(width + x, y, x + width, y + height));
        g2.draw(new Line2D.Double(x, y + height, x + width, y + height));
        g2.draw(new Line2D.Double(x, y, x, y + height));
    }
}
