package com.fawzan.de;
/*
* Nautilus class is to draw the nautilus using curves and squares
* constructor takes the starting point (x,y) that nautilus should draw in the window
* nautilusNmbr array contains the fibbanacci numbers that helps to raw the squares and curves
* */

import java.awt.*;

public class Nautilus extends Shape{

    private  int x,y;// Starting cordinates to draw the nautilus

    //constructor with takes starting cordinates
    public Nautilus(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /*this array contains the fibanacci numbers 0 to 13. for clear the Nautilus
    * those numbers are multiply by 20. these numbers are the height or width of a square
    * otherwise radius of the curves.
    * */
    private int[] nautilusNmbr = {130*2,80*2,50*2,30*2,20*2,10*2,10*2,0};

    /*calculateNewX() method calculate the new x cordinates to draw the new square*/
    public void calculateNewX(int oldX, int length, int angle, int nextLength){
        /* oldX and length are the x cordinates and height or width (fibanacci number)of the
         * preveous square
         * angle is starting point angle of the curve and nextLength is height/width of the
         * new square
         * */
        if (angle == 0){
            x = oldX + length;
        }else if(angle == 90){
            x = oldX;
        }else if (angle == 270){
            x = oldX + length - nextLength;
        }else if (angle == 180){
            x = oldX - nextLength;
        }

    }

    /*calculateNewY() method calculate the new y cordinates to draw the new square*/
    public void calculateNewY(int oldY, int length, int angle, int nextLength){
        /*parameter variables are same as above method. those are apply for y cordinate*/
       if (angle==0){
           y = oldY;
       }else if (angle == 90){
           y = oldY - nextLength;
       }else if (angle == 270){
           y = oldY + length;
       }else if (angle == 180){
           y = oldY + (length - nextLength);
       }
    }

    public void draw(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(this.color);
        int angle = 90;     //starting angle of the curve
        for (int i=0;i<nautilusNmbr.length-1;i++){

            double curveX = x;  // x cordinate for curve
            double curveY = y;  // y cordinate for curve

            //set the x,y cordinates to draw the one curve of a nautilus
            if (angle==0 || angle==270){
                curveX = x- nautilusNmbr[i];
            }
            if (angle==270 || angle==180){
                curveY = y - nautilusNmbr[i];
            }

            Square square = new Square(Color.black.BLUE,this.x, this.y, nautilusNmbr[i], nautilusNmbr[i]);
            square.draw(g);    // draw the square

            Curve curve = new Curve(Color.RED,curveX, curveY, nautilusNmbr[i]*2, nautilusNmbr[i]*2,angle,90 );
            curve.draw(g);     // draw the curve

            /*set the starting angle for the next curve accoding to the current angle*/
            if (angle==90){
                angle = 0;
            }else if(angle==0){
                angle=270;
            }else if(angle==270){
                angle=180;
            }else if(angle==180){
                angle=90;
            }

            /*set the next x,y cordinates*/
            this.calculateNewX(x, nautilusNmbr[i],angle, nautilusNmbr[i+1]);
            this.calculateNewY(y, nautilusNmbr[i],angle,nautilusNmbr[i+1]);
        }
    }
}
