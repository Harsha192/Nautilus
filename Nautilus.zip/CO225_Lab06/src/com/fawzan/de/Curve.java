package com.fawzan.de;

/*Curve class to draw the curve*/

import java.awt.*;
import java.awt.geom.Arc2D;

public class Curve extends Shape{

    /* x,y are starting cordinates
     * start is the starting angle of the curve
     * extent is end angle of the curve
     * with the positive side of the x axis
     * */
    double x, y, height, width, start, extent;


    public Curve(double x, double y, double height, double width, double start, double extent) {
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = width;
        this.start = start;
        this.extent = extent;
    }

    public Curve(Color color, double x, double y, double height, double width, double start, double extent) {
        super(color);
        this.x = x;
        this.y = y;
        this.height = height;
        this.width = width;
        this.start = start;
        this.extent = extent;
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(this.color);

        /*Draw the curve using Arc2D class*/
        g2.draw(new Arc2D.Double(x, y, width, height, start, extent, Arc2D.OPEN));
    }
}
